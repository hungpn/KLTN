/**
 * 
 */
package vn.hus.nlp.tagger;

/**
 * @author LE HONG Phuong, phuonglh@gmail.com
 * <p>
 * Jul 2, 2009, 6:49:11 PM
 * <p>
 * Some parameters of the program which may be changed by command-line options.
 */
public class TaggerOptions {
	public static boolean UNDERSCORE = false;
	public static boolean PLAIN_TEXT_FORMAT = false;
}
